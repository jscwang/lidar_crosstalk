# Two-sensor VL53L1X crosstalk rig (minimal)

Firmware and host software needed to run one guided session on the rig.
The VL53L1X driver in `firmware/lib/vl53l1x_uld` is by STMicroelectronics, under the license in `LICENSE-ST.md` there.

## Setup

    python -m pip install -r requirements.txt

Flash the ESP32-S3 (from `firmware/`):

    python -m platformio run -e esp32s3_wroom2 -t upload --upload-port COM7

## Run (from `host/`)

    python -m rig ports
    python -m rig selftest --port COM7
    python -m rig session --guided --port COM7 --config configs/sweep_0p3m.json --out data

Use the COM number `rig ports` marks for the rig. The config is the 0.3 m sweep, 0 to 12 degrees per side, both zones,
5 repeats. Analysis, export and the simulator are not included.
